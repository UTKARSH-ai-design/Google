let search = document.getElementById("search");
let logo = document.getElementById("logo");
logo.onclick = function() {
  let url = "https://www.google.com/search?q=" + search.value;
  window.open(url, "_self");
}
search.addEventListener("keyup", function(event) {
  if (event.keyCode === 13) {
    event.preventDefault();
    logo.click();
  }
});
